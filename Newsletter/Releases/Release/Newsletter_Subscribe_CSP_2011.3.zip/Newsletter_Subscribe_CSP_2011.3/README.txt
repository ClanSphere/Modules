##### Coder: Fr33z3m4n ####
##### Projekt: Newsletter un/subscribe #####
##### Module f�r ClanSphere 2011.3 v1.2 #####
##### Last Change: 07.03.2012 #####

# # I N F O R M A T I O N : # #
Was macht dieses Module?
Dieses Modul enth�lt eine Navlist-Box, in welches sich Besucher f�r den Newsletter an/abmelden k�nnen.
Der Newsletter wird zus�tzlich an die eingetragenen eMail Adressen geschickt

# # A N L E I T U N G : # #
1. Die Dateien nach der Ordner-Struktur hochladen.
2. Die Datei newsletter_mod.sql unter "System -> Datenbank" ausf�hren.
3. Die Navlist Box per Platzhalter {newsletter:navlist} im Template platzieren.
4. Navlist Box dem Design anpassen.

# # UPDATE v1.0 zu v1.2 # #
1. Sicherstellen, dass vom ClanSphere 2011.3 die Newsletter Dateien genutzt werden.
2. Wenn nicht, die alten Newsletter Dateien l�schen, und mit dem Release updaten
1. Die Dateien nach der Ordner-Struktur hochladen und �berschreiben lassen

# # UPDATE v1.0 zu v1.1 # #
1. Die Dateien nach der Ordner-Struktur hochladen.
2. Die Datei update_1.0_to_1.1 unter "System -> Datenbank -> Import" ausf�hren.
 
# # K O N T A K T : # #
e-Mail: info@fastwebs24.de
WWW: http://www.fastwebs24.de
WWW: http://www.fr33z3m4n.de
WWW: http://www.clansphere.net


########################################################
// Changelog

--------------------------------------------------------
Newsletter un/subscribe v1.2 (07.03.2012)
--------------------------------------------------------
- update to clansphere 2011.3
- bugfixes
- newsletter now available to send clansphere users

--------------------------------------------------------
Newsletter un/subscribe v1.1 (14.03.2010)
--------------------------------------------------------
- added activation
- added eMail Lists

--------------------------------------------------------
Newsletter un/subscribe v1.0 (06.03.2010)
--------------------------------------------------------
- Grundversion f�r 2009.0.3 erstellt


