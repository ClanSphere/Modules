<?php
$cs_lang = cs_translate('newsletter');
$data = array();

echo cs_subtemplate(__FILE__,$data,'newsletter','navlist');