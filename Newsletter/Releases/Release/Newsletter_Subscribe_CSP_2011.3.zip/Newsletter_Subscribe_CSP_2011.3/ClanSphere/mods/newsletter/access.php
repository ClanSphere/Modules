<?php
// ClanSphere 2010 - www.clansphere.net
// $Id: access.php 4565 2010-09-13 20:02:06Z hajo $

$axx_file['remove']    = 5;
$axx_file['create']    = 3;
$axx_file['manage']    = 3;
$axx_file['view']      = 3;
$axx_file['center']    = 2;
$axx_file['export']    = 5;


/* NewsLetter Mod */
$axx_file['subscribe']    = 1;
$axx_file['emaillist']    = 5;
$axx_file['activate']    = 1;
$axx_file['navlist']    = 1;