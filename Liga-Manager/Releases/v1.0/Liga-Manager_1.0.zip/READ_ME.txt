##### Coder: Fr33z3m4n ####
##### Projekt: Liga-Manager v1.0 #####
##### Module f�r ClanSphere 2008 (CS08) #####
##### Last Change: 28.04.2008 #####

# # I N F O R M A T I O N : # #
Was macht dieses Module?
Mit diesem Module kann man f�r sein Verein oder sonstiges Ligen verwalten. (Bundesliga etc.)

# # A N L E I T U N G : # #
1. Die Dateien nach der Ordner-Struktur hochladen.
2. Die Datei liga_manager.sql unter "System -> Datenbank -> Import" ausf�hren.
4. Ligen erstellen
5. Teams erstellen
6. Die Teams den jeweiligen Ligen zuteilen
7. Spiele erstellen

 
# # K O N T A K T : # #
e-Mail: Fr33z3m4n@clansphere.de
WWW: http://www.clansphere.net
WWW: http://www.fr33z3m4n.de
WWW: http://www.fastwebs24.de


########################################################
// Changelog

--------------------------------------------------------
Liga-Manager v1.0 (28.04.2008)
--------------------------------------------------------
- Created Version

