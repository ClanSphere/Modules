<?php
$axx_file['manage'] = 4;
$axx_file['manage_ligen'] = 4;
$axx_file['create_liga'] = 4;
$axx_file['edit_liga'] = 4;
$axx_file['remove_liga'] = 4;
$axx_file['manage_teams'] = 4;
$axx_file['create_team'] = 4;
$axx_file['edit_team'] = 4;
$axx_file['remove_team'] = 4;
$axx_file['manage_ttl'] = 4;
$axx_file['create_ttl'] = 4;
$axx_file['remove_ttl'] = 4;
$axx_file['manage_games'] = 3;
$axx_file['create_game'] = 3;
$axx_file['edit_game'] = 3;
$axx_file['remove_game'] = 3;
$axx_file['list'] = 0;

?>